# Rememberly

Rememberly is a polished memory-vault web app by **Oketola Michael Oloruntofunmi**, Founder & Builder.

## Pages
- `/` — Landing
- `/login.html` — Login
- `/signup.html` — Create account
- `/dashboard.html` — Dashboard
- `/new-memory.html` — Create memory
- `/favorites.html` — Favorites
- `/search.html` — Search
- `/settings.html` — Settings
- `/about.html` — About

## Deploy on Render
This package is prepared as a Node/Express web service. Render supports Node web services and requires the app to listen on `0.0.0.0`; this project does that automatically.

Build command: `npm install`
Start command: `npm start`

### Important
This version stores demo account and memory data in the browser's `localStorage`. It is **not** a production database or secure authentication system. For a real public product, connect a proper backend/auth system such as a hosted Postgres + authentication service before collecting real user data.
